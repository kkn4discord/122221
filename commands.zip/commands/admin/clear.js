const { SlashCommandBuilder } = require('@discordjs/builders');

const data = new SlashCommandBuilder()
    .setName('clear')
    .setDescription('مسح رسالة')
    .addIntegerOption(option =>
        option.setName('عدد').setDescription('عدد الرسائل المراد مسحها').setRequired(true));

module.exports = {
    data: data,
    async execute(interaction) {
        const amount = interaction.options.getInteger('عدد');
        if (amount <= 1 || amount > 100) {
            return interaction.reply('يجب أن يكون العدد بين 1 و 100!');
        }
        await interaction.channel.bulkDelete(amount);
        interaction.reply(`تم مسح ${amount} رسالة!`);
    },
};