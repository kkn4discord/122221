const { SlashCommandBuilder, Interaction, EmbedBuilder, PermissionFlagsBits } = require("discord.js");
const ms = require('ms');

module.exports = {

    data: new SlashCommandBuilder()
        .setName('timeout')
        .setDescription('اعطاء تايم اوت لعضو')
        .setDMPermission(false)

        .addUserOption(user => user
            .setName('user')
            .setDescription('منشن العضو')
            .setRequired(true)
        )

        .addStringOption(reason => reason
            .setName('reason')
            .setDescription('السبب')
            .setRequired(true)
        )

        .addStringOption(time => time
            .setName('time')
            .setDescription('المده (e.g. 1h30m)')
            .setRequired(true)
        ),

    /**
    * @param { Interaction } interaction 
    * @param { Client } client 
    */

    async execute(interaction, client) {
        const member = interaction.options.getMember('user');
        const reason = interaction.options.getString('reason');
        const channel = interaction.guild.channels.cache.get('channel_id');
        const timee = interaction.options.getString('time');

        if (!interaction.member.permissions.has(PermissionFlagsBits.BAN_MEMBERS)) {
            return interaction.reply({ content: 'You do not have permission to Time out members.' });
        }

        if (!channel) {
            return interaction.reply({ content: 'Invalid channel ID.' });
        }

        if (!member) {
            return interaction.reply({ content: 'Please provide a valid member to timeout.' });
        }

        if (member.id === interaction.user.id) {
            return interaction.reply({ content: 'You cannot timeout yourself.' });
        }

        if (member.id === client.user.id) {
            return interaction.reply({ content: 'You cannot timeout me.' });
        }

        try {
            const timeSp = ms(timee);
            if (isNaN(timeSp)) throw new Error('Invalid timeout duration');

            const endTime = new Date(Date.now() + timeSp);
            const seconds = Math.floor(timeSp / 1000);

            await member.timeout(timeSp, { reason: reason || 'No reason provided.' });

            const embed = new EmbedBuilder()
                .setDescription(`
                  > **User** | ${member} (${member.id})
                  > **Time** | ${seconds} seconds
                  > **Ends at** | ${endTime.toLocaleString()}
                  > **Reason** | ${reason || 'No reason provided.'}
                  > **Moderator** | ${interaction.user} (${member.id})
                `);
            embed.setColor('Black')
            embed.setThumbnail(interaction.guild.iconURL({ dynamic: true }))

            await channel.send({ embeds: [embed] });
            return await interaction.reply({ content: `${member} has been Timeout.` });
        } catch (error) {
            return await interaction.reply({ content: `An error occurred while trying to Timeout ${member}. Error: \`\`\`${error}\`\`\`` });
        }
    }
}