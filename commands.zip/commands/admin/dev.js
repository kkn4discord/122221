const { EmbedBuilder , SlashCommandBuilder, Client, ChatInputCommandInteraction} = require('discord.js');
module.exports = {
    data: new SlashCommandBuilder()
      .setName('devloper')
      .setDescription('رؤيه مطور البوت'),
      
    async execute(interaction, client) {
       
        const embed = new EmbedBuilder()
            .setColor('#020000')
            .setThumbnail(client.user.displayAvatarURL())
            .setTitle('devlopers Bot')
            .setDescription(`> **Verson : 14.11.0
> Devloper bot : <@1071810231392272465>
> bot work : System
> لقمت التونه صعبه بردو**`)
            .setTimestamp()
            .setFooter({ text: 'Developed By RIO', iconURL: 'https://cdn.discordapp.com/attachments/1168874470665101342/1172929796653723788/IMG_4254.webp?ex=65621aff&is=654fa5ff&hm=a6fc21b2dfa060aba063f8d0&' });

        
        await interaction.reply({ embeds: [embed], ephemeral: true });
    },
};