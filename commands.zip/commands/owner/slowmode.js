const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const ms = require('ms')
const humanizeDuration = require('humanize-duration')

module.exports = {
    data:new SlashCommandBuilder()
    .setName('slowmode')
    .setDescription('صنع وقت في الرووم')
    .addStringOption(Option => 
        Option
        .setName('value')
        .setDescription('Type (off) for Disable the Slomode in the Channel or Enter the Time')
        .setRequired(true))
        .addChannelOption(option => 
            option
            .setName('channel')
            .setDescription('Select the Channel')
            .setRequired(false)),
    /**
     * @description 
     * @param { Client } Client
     * @param { ChatInputCommandInteraction } Interaction 
     */

            async execute(Interaction, Client) {
        const Channel = Interaction.options.getChannel('channel') || Interaction.channel;
        const Value = Interaction.options.getString('value')
if (!Interaction.member.permissions.has("ManageChannels")) return Interaction.reply({content:`**😕 You don't have permission **`, ephemeral: true})
        const Embed = new EmbedBuilder()
            .setTitle('Command: slowmode')
            .setDescription('Enable or disable slowmode on a channel.')
            .addFields({ name: 'Usage:', value: '/slowmode\n/slowmode [time]\n/slowmode [channel] [time]\n/slowmode off' })
            .addFields({ name: 'Examples:', value: '/slowmode\n/slowmode #general 10s\n/slowmode 10s\n/slowmode off' })

        if(!Value) {
            const ChannelRateLimitPer = Channel.rateLimitPerUser;
            const Milliseconds = ms(ChannelRateLimitPer)
            await Interaction.reply({ content: `:stopwatch: This channel slowmode is **${humanizeDuration(ms(Milliseconds), { round: true })}**.` })
        }

        if(Value === 'off' || Value === 'OFF') {
            await Channel.setRateLimitPerUser(0)
            Interaction.reply({ content: `:stopwatch: Slowmode has been disabled from this channel.` })
        } else {
            const Milliseconds = ms(Value)
            if(isNaN(Milliseconds)) return Interaction.reply({ embeds: [Embed], ephemeral: true })
            if(Milliseconds < 1000) return Interaction.reply({ embeds: [Embed], ephemeral: true })
            await Channel.setRateLimitPerUser(Milliseconds / 1000)
            if(Milliseconds > 21600) return Interaction.reply({ content: `:no_entry: Time should be less than or equal to **6 hours.**` })
            await Interaction.reply({ content: `:stopwatch: This channel slowmode has been set to **${ms(Milliseconds, { long: true })}**.` })
        }
  }
}