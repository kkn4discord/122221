const { SlashCommandBuilder } = require('@discordjs/builders');
const { Client, ChatInputCommandInteraction, EmbedBuilder, PermissionFlagsBits, ChannelType  } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('hide')
    .setDescription('اخفاء الرووم عن الاعضاء')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addChannelOption(option => option.setName('channel').setDescription('the channel you want to hide').addChannelTypes(ChannelType.GuildText).setRequired(false)),

    /**
     * @param {ChatInputCommandInteraction} interaction 
     * @param {Client} client
     */

  async execute(interaction, client) {

    let channel = interaction.options.getChannel('channel') || interaction.channel;

    channel.permissionOverwrites.edit(interaction.guild.id, { ViewChannel: false })

    const embed = new EmbedBuilder()
    .setTitle(`> **${channel} Has Been Hidden 🔒**`)
    .setFooter({ text: 'Developed By RIO', iconURL: client.user.displayAvatarURL({ dynamic: true }) })
    .setColor('Gold');

    await interaction.reply({ embeds: [embed] })
  },
};