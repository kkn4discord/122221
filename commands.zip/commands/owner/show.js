const { SlashCommandBuilder } = require('@discordjs/builders');
const { Client, ChatInputCommandInteraction, EmbedBuilder, PermissionFlagsBits, ChannelType  } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('show')
    .setDescription('ليسطيع الاعضاء رؤيه الرووم')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addChannelOption(option => option.setName('channel').setDescription('the channel you want to show').addChannelTypes(ChannelType.GuildText).setRequired(false)),

    /**
     * @param {ChatInputCommandInteraction} interaction 
     * @param {Client} client
     */

  async execute(interaction, client) {

    let channel = interaction.options.getChannel('channel') || interaction.channel;

    channel.permissionOverwrites.edit(interaction.guild.id, { ViewChannel: true })

    const embed = new EmbedBuilder()
    .setTitle(`> **${channel} Has Been Shown🔒**`)
    .setFooter({ text: 'Developed By DeXTeR', iconURL: client.user.displayAvatarURL({ dynamic: true }) })
    .setColor('Gold');

    await interaction.reply({ embeds: [embed] })
  },
};