const { SlashCommandBuilder,PermissionFlagsBits,EmbedBuilder } = require('discord.js')
module.exports = {
  data: new SlashCommandBuilder()
  .setName('avatar-server')
  .setDescription('لاظهار افتار السرفر'),

  async execute(interaction, client) {
    let clientMember = await interaction.guild.members.fetch(client.user.id);
    if (!clientMember.permissions.has(PermissionFlagsBits.SendMessages)) return interaction.reply({content: `Im Dont Have Permission`, ephemeral: true})
    let embed = new EmbedBuilder()

      .setAuthor({ name: interaction.user.tag, iconURL: interaction.user.displayAvatarURL({ dynamic: true}) })
     .setFooter({ text: `Requested by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
   .setDescription(`[Server Avatar link](${interaction.guild.iconURL({dynamic: true, size: 4096})})`)
    .setImage(`${interaction.guild.iconURL({dynamic: true, size: 4096})}`)

   await interaction.reply({embeds: [embed], ephemeral: true})
  }
}