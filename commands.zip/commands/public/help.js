const { SlashCommandBuilder, EmbedBuilder, StringSelectMenuBuilder, ActionRowBuilder, ChatInputCommandInteraction, Client, ComponentType } = require('discord.js')

module.exports = {
    data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('رويه جميع الاوامر'),
    async execute(interaction, client) {
        if(!interaction.inGuild()) return await interaction.reply({ content: 'The Slash Commands Only Working In Servers ❌', ephemeral: true });

        try {
            const embed = new EmbedBuilder()
            .setColor('Blue')
            .setTitle('**Help**')
            .setDescription(`مرحبا بك انا : بوت سيستم سلاش كوماند 

مطوري  :    <@1071810231392272465>

عدد اوامر : 29

نوع الأوامر : سلاش كوماند`)
            //.setImage
            const select = new StringSelectMenuBuilder()
            .setCustomId('1')
            .setPlaceholder('Nothing Selected')
            .addOptions(
            {
                label: 'owner', value: '1', description: 'owner Cmds', // emoji: ''
            },
            {
                label: 'Admin', value: '2', description: 'Admin Cmds', // emoji: ''
            },
            {
                label: 'public', value: '3', description: 'Public Cmds', // emoji: ''
            },
            {
                label: 'settings', value: '4', description: 'Show settings', // emoji: ''
            },
            {
                label: 'Fun', value: '5', description: 'Fun Cmds', // emoji: ''
            },
            {
                label: 'Game', value: '6', description: 'Playing Cmds', // emoji: ''
            },
            {
                label: 'giveaway', value: '7', description: 'Giveaway Cmds', // emoji: ''
            },            
            )

            const row = new ActionRowBuilder().addComponents(select)

            await interaction.reply({ embeds: [embed], components: [row] }).then(async() => {

                const collector = interaction.channel.createMessageComponentCollector({
                    componentType: ComponentType.StringSelect,
                    time: 60000,
                })
                collector.on('collect', async (collected) => {
                    const value = collected.values[0];

                    if (value === '1') {
                     const user = interaction.user;

                        const embed = new EmbedBuilder()
        .setColor('Blue')
        .setTitle('owner')
        .setDescription(`
        /ban
        /unban 
        /kick
        /lock
        /unlock
        /hide
        /show
        /rolegive
        /roleremove
        /listban
        /slowmode
        /serverphoto`)
.setThumbnail(user.displayAvatarURL())
.setTimestamp()

                        collected.reply({ embeds: [embed], ephemeral: true })
                    } else if (value === '2') {
                        const user = interaction.user;

                        const embed = new EmbedBuilder()
                        .setColor('Blue')
                        .setTitle('Admin')
                        .setDescription(`/add-sticker
                    /addemoji
                    /clear/come
                    /devloper
                    /ping
                    /say
                    /setnick
                    /timout`)
.setThumbnail(user.displayAvatarURL())
collected.reply({ embeds: [embed], ephemeral: true })
                    } else if (value === '3') {
                        const user = interaction.user;

                        const embed = new EmbedBuilder()
                        .setColor('Blue')
                        .setTitle('public')
                        .setDescription(`/afk
                        /banner
                        /avatar
                        /user
                        /tax
                        /server
                        /question`)
.setThumbnail(user.displayAvatarURL())
collected.reply({ embeds: [embed], ephemeral: true })
                    } else if (value === '4') {
                        const user = interaction.user;

                        const embed = new EmbedBuilder()
                        .setColor('Blue')
                        .setTitle('Settings')
                        .setDescription(`Commands`)
.setThumbnail(user.displayAvatarURL())
collected.reply({ embeds: [embed], ephemeral: true })
                    } else if (value === '5') {
                        const user = interaction.user;

                        const embed = new EmbedBuilder()
                        .setColor('Blue')
                        .setTitle('Fun')
                        .setDescription(`Commands`)
.setThumbnail(user.displayAvatarURL())
collected.reply({ embeds: [embed], ephemeral: true })
                    } else if (value === '6') {
                        const user = interaction.user;

                        const embed = new EmbedBuilder()
                        .setColor('Blue')
                        .setTitle('Game')
                        .setDescription(`Commands`)
.setThumbnail(user.displayAvatarURL())
collected.reply({ embeds: [embed], ephemeral: true })
                    } else if (value === '7') {
                        const user = interaction.user;

                        const embed = new EmbedBuilder()
                        .setColor('Blue')
                        .setTitle('Giveaway')
                        .setDescription(`Commands`)
.setThumbnail(user.displayAvatarURL())
collected.reply({ embeds: [embed], ephemeral: true })
                    }
                })
            })
        } catch (error) {
            console.error(error);

        }
    }
    }