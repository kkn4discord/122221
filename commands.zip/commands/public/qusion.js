const { SlashCommandBuilder, MessageCollector } = require('discord.js');
const words = ['موز', 'تفاح']

module.exports = {
    data: new SlashCommandBuilder()
        .setName('question')
        /**
         * @param {Object} param0
         * @param {import('discord.js').ChatInputCommandInteraction} param0.interaction
         */
        .setDescription('لعبه اساله'),
    async execute(interaction) {
        const answer = words[Math.floor(Math.random() * words.length)];

        await interaction.reply(
            'Game Started! guess a word from the following list:\n\n' + words.join('\n')
        )

        const collector = interaction.channel.createMessageCollector({
            filter: (message) => message.content === answer && message.channelId === interaction.channelId,
            time: 10_000,
        });

        let answered = false;

        collector.on('collect', (message) => {
            message.reply('You corectly guessed the word!')

            answered = true;
            collector.stop()
        });

        collector.on('end', () => {
            if (!answered) {
            interaction.followUp(
                `No one correctly guessed the word correctly. The Answer was ${answer}`
            )
            }
        })
    }
}