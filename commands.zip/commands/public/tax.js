const { EmbedBuilder, ChatInputCommandInteraction, SlashCommandBuilder } = require('discord.js')

module.exports = {
    data: new SlashCommandBuilder()
    .setName('tax')
    .setDescription('تاكس برو بوت')
    .addStringOption(option => option.setName('amount').setDescription('The Amount Of Credits').setRequired(true)),

    /**
     * @param {ChatInputCommandInteraction} interaction 
     */

    async execute(interaction) {
        let amount = interaction.options.getString('amount');
        let amount2 = amount.replace("k","000").replace("m", "000000").replace('M', "000000").replace('K', "000").replace('b',"000000000000").replace('B',"000000000000")
        let tax = Math.floor(amount2 * (20) / (19) + (1));

        let embed = new EmbedBuilder()
        .setDescription(`> **Done Send all Tax**\n\n> **Tax Here  \`${tax}\`**`)
        .setColor('Red')
        .setTimestamp();

        if (!amount2) return await interaction.reply({ content: "Invalid Input", ephemeral: true });
        if (isNaN(amount2)) return await interaction.reply({ content: "Invalid Input", ephemeral: true });

        await interaction.reply({ embeds: [embed] });


    }
}